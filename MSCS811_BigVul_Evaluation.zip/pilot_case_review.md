# MSCS811 pilot case review

These were the only pilot functions on which the predicted verdict changed across A, B, and C. The reference is the BigVul label.

| Sample | Reference | A | B | C | Observation |
|---|---:|---:|---:|---:|---|
| P03 | 1 | 0 | 1 | 1 | Both reviews changed the verdict to match the reference label. The reason differs from A only in trailing punctuation and ends mid-thought. |
| P13 | 0 | 0 | 1 | 0 | C agreed with the reference label while B raised an alert. All three reasons were identical. The explanation assumed an input other than a Boolean without support from the Boolean parameter declaration. |
| P17 | 0 | 0 | 1 | 1 | Both reviews changed a correct A verdict to a false alert relative to the reference label. All three reasons were identical. |

A change in verdict on these cases did not correspond to a substantive change in the recorded reason. Keep verdict performance and explanation quality separate.

The evaluation set is a balanced, held-out sample drawn from the mirror test split. The recorded tag C is a dataset metadata filter. Some projects can be present in both partitions, and the balance does not represent operational prevalence.

Frozen prompts, model configuration, row identifiers, hashes, and the sampler are included in the archive. Send only model_inputs.jsonl code to the model. Use reference_labels.jsonl for scoring.
